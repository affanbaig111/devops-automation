package com.example.cab_book_driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookDriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
