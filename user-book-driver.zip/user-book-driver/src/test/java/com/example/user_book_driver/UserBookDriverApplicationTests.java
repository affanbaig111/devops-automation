package com.example.user_book_driver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserBookDriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
